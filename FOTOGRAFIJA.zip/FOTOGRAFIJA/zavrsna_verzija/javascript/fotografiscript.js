// pokušaj sakrivanja teksta kod fotografa

/* $(document).ready(function(){
    $("#hide").click(function(){
      $("#p1").hide();
    });
$("#show").click(function(){
      $("#p1").show();
    });
});
 */
/* $(document).ready(function(){
    $(".dugme").click(function(){
      $("p").toggle();
    });
  }); */


 /*  $("button").click(function(){
    $(".p").hide();
  }); */
